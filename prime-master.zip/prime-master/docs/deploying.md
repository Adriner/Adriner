# Deploying

We support one-click deployments with heroku

## Heroku

One-click deployment is available for Heroku:

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/primecms/heroku)

Includes support for addons like Cloudinary, Newrelic, Algolia and Sentry.
