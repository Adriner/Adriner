<i style="font-size: 72px; font-family: system;">prime</i>

> Open Source GraphQL CMS

- 🖨 Headless Interface
- 🚀 Simple, yet Powerful
- 📐 Slices and Groups
- ☑️ Custom Fields
- 🇮🇸 🇯🇵 Multi Language
- 🚧 Preview Drafts
- 🔑 Access Control
- 📆 Plan Releases

[Get Started](README)
[GitHub](https://github.com/birkir/prime)
