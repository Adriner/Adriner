export { PrimeFieldGeoPoint as default } from './PrimeFieldGeoPoint';
