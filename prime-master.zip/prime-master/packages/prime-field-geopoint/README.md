# `prime-field-geopoint`

Geo point field
