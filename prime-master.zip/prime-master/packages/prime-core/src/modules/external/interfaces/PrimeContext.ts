import { Request } from 'express';

export interface PrimeContext {
  req: Request;
}
