import { PubSub } from 'graphql-subscriptions';

export const pubSub = new PubSub();
