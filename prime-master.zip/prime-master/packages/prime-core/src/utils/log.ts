import debug from 'debug';

export const log = debug('prime:server');
