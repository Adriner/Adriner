# @primecms/ui

> Front-end interface for prime

See our [docs](https://birkir.github.io/prime) for more information or the [issues](https://github.com/birkir/prime/issues) associated with this package.

## Install

Using npm:

```sh
npm install --save-dev @primecms/ui
```

or using yarn:

```sh
yarn add @primecms/ui --dev
```
