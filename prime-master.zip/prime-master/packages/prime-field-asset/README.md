# `prime-field-asset`

Upload Images, Videos and other assets.

Backed with Cloudinary.

### Required environment variable

- `PRIME_CLOUDINARY_URL`

Example:

```bash
PRIME_CLOUDINARY_URL=cloudinary://apiKey:apiSecret@bucketName
```
