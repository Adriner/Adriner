declare module 'react-easy-crop';
