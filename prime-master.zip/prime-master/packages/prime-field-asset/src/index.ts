export { PrimeFieldAsset as default } from './PrimeFieldAsset';
