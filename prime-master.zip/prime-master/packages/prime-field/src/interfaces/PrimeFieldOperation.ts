export enum PrimeFieldOperation {
  READ,
  CREATE,
  UPDATE,
}
