export enum SchemaVariant {
  Default = 0,
  Slice = 1,
  Template = 2,
}
