export { PrimeFieldNumber as default } from './PrimeFieldNumber';
