# `prime-field-boolean`

Boolean field
