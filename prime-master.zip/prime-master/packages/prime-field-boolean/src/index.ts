export { PrimeFieldBoolean as default } from './PrimeFieldBoolean';
