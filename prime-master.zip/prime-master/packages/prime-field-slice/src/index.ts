export { PrimeFieldSlice as default } from './PrimeFieldSlice';
