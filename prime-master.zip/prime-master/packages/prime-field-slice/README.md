# `prime-field-slice`

> TODO: description

## Usage

```
const primeFieldString = require('prime-field-string');

// TODO: DEMONSTRATE API
```
