export { PrimeFieldSelect as default } from './PrimeFieldSelect';
