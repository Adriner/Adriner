export { PrimeFieldDocument as default } from './PrimeFieldDocument';
