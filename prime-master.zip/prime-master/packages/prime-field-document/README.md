# `prime-field-document`

> TODO: description

## Usage

```
const primeFieldDocument = require('prime-field-document');

// TODO: DEMONSTRATE API
```
