export { PrimeFieldString as default } from './PrimeFieldString';
