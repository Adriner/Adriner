# `prime-field-string`

Single or multiline string
