import { runFieldPropertiesTest } from '@primecms/field/lib/tests';
import PrimeFieldString from '../src';

runFieldPropertiesTest(PrimeFieldString);
