# `prime-field-group`

> TODO: description

## Usage

```
const primeFieldGroup = require('prime-field-group');

// TODO: DEMONSTRATE API
```
