export { PrimeFieldGroup as default } from './PrimeFieldGroup';
